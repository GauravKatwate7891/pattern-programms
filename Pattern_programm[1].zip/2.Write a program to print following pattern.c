#include<stdio.h>
#include<conio.h>

void print(int);

int main()
{
    int cnt=0;

    printf("\n Please Enter Only Odd Number To Get Pattern=>");
    scanf("%d",&cnt);
    clrscr();
    if(cnt%2==1)
    {
        print(cnt);
    }
    else
    {
        printf("\n You Are Enterd Even Number...");
    }
    getch();
    printf("\nThanks...");
    getch();
    return 0;
}

void print(ino)
{
    int i=0,j=0;
    char ch='A';

    for(i=0; i<ino; i++)
    {
        for(j=0; j<ino; j++)
        {
            if(i>=j)
            {
                printf(" %c ",ch);
            }
            else
            {
                printf("   ");
            }
            ch++;
        }
        printf("\n");
    }
}
#include<stdio.h>
#include<conio.h>

void Enter_Cnt();
void Print_Pattern(int);

int main()
{
    Enter_Cnt();
    printf("\n Thanks...");
    getch();
    return 0;
}

void Enter_Cnt()
{
    int cnt=0;
    printf("\n Enter The Only Odd Number=>");
    scanf("%d",&cnt);
    clrscr();

    if(cnt%2==1)
    {
        Print_Pattern(cnt);
    }
    else
    {
        printf("\n You Are Enterd Even Number...");
    }
}

void Print_Pattern(ino)
{
    int i=0,j=0;

    for(i=1; i<=ino; i++)
    {
        for(j=1; j<=ino; j++)
        {
            if(i>=j)
            {
                printf(" %d ",7);
            }
            else
            {
                printf("   ");
            }
        }
        printf("\n");
    }
}
